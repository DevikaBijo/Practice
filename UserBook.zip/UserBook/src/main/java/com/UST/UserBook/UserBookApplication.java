package com.UST.UserBook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserBookApplication.class, args);
	}

}
