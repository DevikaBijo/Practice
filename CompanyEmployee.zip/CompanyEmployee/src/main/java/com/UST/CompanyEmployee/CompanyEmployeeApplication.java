package com.UST.CompanyEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanyEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanyEmployeeApplication.class, args);
	}

}
