package com.UST.StudentDepartment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDepartmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDepartmentApplication.class, args);
	}

}
