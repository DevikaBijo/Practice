package com.UST.StudentDepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
