package com.UST.Sample_College;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleCollegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleCollegeApplication.class, args);
	}

}
