package com.example.SamplePratice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamplePraticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamplePraticeApplication.class, args);
	}

}
